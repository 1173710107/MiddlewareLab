package lab6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;


public class keepfair implements Runnable {

  private int sumNumber = -1;
  private double throughtRate;
  private double justification = 0;
  private static int sum = 0;
  public static void update(){
    sum++;
  }


  public keepfair(int sumNumber) {
    this.sumNumber = sumNumber;
    setThroughtRate(0);
    setJustification(0);
  }

  public int getSumNumber() {
    return sumNumber;
  }

  public double getThroughtRate() {
    return throughtRate;
  }

  public void setThroughtRate(double throughtRate) {
    this.throughtRate = throughtRate;
  }

  public double getJustification() {
    return justification;
  }

  public void setJustification(double justification) {
    this.justification = justification;
  }

  @Override
  public void run() {
    long starttime = System.currentTimeMillis();
    int time = 1;
    boolean end = true;
    do {
      end = true;
      for (Map.Entry<Integer, monkey> monkeyEntry : MonkeyGenerator.getMonkeys().entrySet()) {
        if (monkeyEntry.getValue().getRungNumber() != 21) {
          end = false;
          break;
        }
      }

      if (!end) {
        time++;
      }

      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    } while (!end);
    long endtime = System.currentTimeMillis();
    double during = endtime - starttime;
    Double rate = 1000 * sum / during;
    Logger logger = Logger.getLogger(keepfair.class);
    logger.setLevel(Level.INFO);
    setThroughtRate(getSumNumber() * 1.0 / time);

    logger.info("猴子过桥的吞吐率是 " + getThroughtRate() + "n/s");
    logger.info("共耗时 " + during/1000 + "s");
    logger.info("消息中间件传递消息共 " + sum);
    logger.info("消息中间件的吞吐率是 " + rate + "n/s");

    List<monkey> monkeysList =
        Collections.synchronizedList(new ArrayList<>(MonkeyGenerator.getMonkeys().values()));
    for (int i = 0; i < sumNumber - 1; ++i) {
      for (int j = i + 1; j < sumNumber; ++j) {
        int sleep1 = monkeysList.get(i).getSleep();
        int age1 = monkeysList.get(i).getAge();
        int sleep2 = monkeysList.get(j).getSleep();
        int age2 = monkeysList.get(j).getAge();

        if ((sleep2 - sleep1) * (sleep2 + age2 - sleep1 - age1) >= 0) {
          justification++;
        } else {
          justification--;
        }
      }
    }
    this.justification = justification * 2.0 / sumNumber / (sumNumber - 1);
    logger.info(" 公平性" + getJustification() + ".");

  }

}
