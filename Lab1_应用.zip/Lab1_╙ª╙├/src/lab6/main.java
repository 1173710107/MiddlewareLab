package lab6;

public class main {
  public static void main(String argv[]) {
    MonkeyGenerator.generateMonkeys(5, 2, 20, 10);
  }
}
