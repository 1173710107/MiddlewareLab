<template>
    <d2-container type="ghost">
        <d2-module-index-banner slot="header" v-bind="info" v-if="refresh"/>
        <!--        <div>{{info}}</div>-->
    </d2-container>
</template>

<script>
  import util from '@/libs/util.js'

  const personApi = require('@/api/person')

  export default {
    name: 'person',
    data () {
      return {
        refresh: true,
        info: {
          name: '',
          username: ''
        }
      }
    },
    created () {
      const id = util.cookies.get('uuid')
      personApi.search({ id: id }).then(res => {
        this.info = res.data
        this.info['title'] = this.info.name
        this.info['subTitle'] = this.info.username
        this.refresh = false
        this.$nextTick(() => {
          this.refresh = true
        })
        console.log(this.info)
      })
    }
  }
</script>

<style scoped>

</style>
