<template>
    <d2-container>
        <div class="layout" id="depManagement">
            <el-card class="box-card">
                <div class="clearfix" slot="header">
                    <span class="title">部门列表</span>
                </div>
                <el-tree
                        :data="data"
                        :expand-on-click-node="false"
                        :props="defaultProps"
                        default-expand-all
                        node-key="id"
                        style="width:80%;margin: 0 auto;"
                        v-loading="loading">
            <span class="custom-tree-node" slot-scope="{ node, data }">
              <span style="font-size: 14px;">{{ node.label }}</span>
              <span v-if="data.id!==-1">
                <el-link :underline="false" @click="() => addItem(data.type)"
                         type="text"
                         v-if="data.id<-1">
                  <i class="iconfont iconfont-add-fill fontStyle "
                     style="margin-right:0;font-size: 14px;color: #67C23A;"/>
                </el-link>

                <el-link :underline="false" @click="() => editItem(data)"
                         type="text"
                         v-if="data.id>-1">
                  <i class="iconfont iconfont-bianji fontStyle" style="color: #E6A23C"/>
                </el-link>
                <el-link :underline="false" @click="addPerson(data)" style="color: #409EFF;" v-if="data.id>-1">
                   <i class="iconfont iconfont-tianjiaren fontStyle"
                      style="margin-left: 10px;font-size:22px;"/>
                </el-link>
                <el-link :underline="false" @click="() => deleteItem(data)"
                         type="text"
                         v-if="data.id>-1">
                    <i class="iconfont iconfont-chushaixuanxiang" style="color: #F56C6C;"/>
                </el-link>
              </span>
            </span>
                </el-tree>
                <!--                <el-dialog :title="dialogType==='edit'?`编辑${title}`:`新增${title}`" :visible.sync="dialogVisible">-->
                <!--                    <el-form :model="dialogData" ref="dialogData" :rules="dialogFormRules">-->
                <!--                        <el-form-item label="商品名称" label-width="13%" prop="name">-->
                <!--                            <el-input v-model="dialogData.name"/>-->
                <!--                        </el-form-item>-->
                <!--                        <el-form-item label="商品单位" label-width="13%" prop="unit">-->
                <!--                            <el-input v-model="dialogData.unit"/>-->
                <!--                        </el-form-item>-->
                <!--                        <el-form-item label="商品类别" label-width="13%" prop="category">-->
                <!--                            <el-input v-model="dialogData.category"/>-->
                <!--                        </el-form-item>-->
                <!--                    </el-form>-->
                <!--                    <div slot="footer" class="dialog-footer">-->
                <!--                        <el-button type="primary" @click="submit()">确 定</el-button>-->
                <!--                        <el-button @click="dialogVisible = false">取 消</el-button>-->
                <!--                    </div>-->
                <!--                </el-dialog>-->
            </el-card>
        </div>
    </d2-container>
</template>

<script>
  const departmentApi = require('@/api/departmentManagement')
  const warehouseApi = require('@/api/warehouse')

  export default {
    data () {
      return {
        // 为分页传路径
        // 查看角色人员时想后台传输的分页数据
        empNumquery: {
          departId: '',
          curr: 1,
          size: 5,
          total: null
        },

        depSwitchValue: true,
        data: [{
          id: -1,
          name: '总部',
          childList: [
            {
              id: -3,
              name: '仓库',
              type: 'inventory',
              childList: []
            },
            {
              id: -2,
              name: '商店',
              type: 'shop',
              childList: []
            }
          ]
        }],
        personData: [],
        addPersons: [],
        deleteDialogVisible: false,
        addPersonDialogVisible: false,
        addDepartmentDialogVisible: false,
        employeesViewDialogVisible: false,
        formLabelWidth: '100px',
        departId: null,
        // 添加或修改存放弹框表单的值
        addDepartmentForm: {
          departName: null,
          departType: null,
          departLevel: null,
          parentName: null,
          departId: null
        },
        // 添加或修改存放弹框表单值的验证规则
        addDepartmentFormRules: {
          departName: [
            { required: true, message: '请填写部门名称', trigger: 'blur' }
          ]
        },
        // 树形菜单 选择当前行的值
        selectedDepartmentValue: {},
        showEmployeesData: [],
        parentName: '',
        dialogType: 'add',
        departmentName: '',
        deleteState: {
          state: false,
          message: ''
        },
        defaultProps: {
          children: 'childList',
          label: 'name'
        },
        loading: false
      }
    },
    created () {
      this.getTreeData()
    },
    methods: {
      getTreeData () {
        this.loading = true
        departmentApi.getDepartments().then(res => {
          if (res.status === 200) {
            this.loading = false
            console.log(res)
            this.data[0].childList[0].childList = [...res.data]
          } else {
            this.$notify.error({ title: res.message })
          }
        }).catch(err => {
          console.log(err)
          this.$notify.error({ title: '请刷新重试' })
        })
        departmentApi.getStores().then(res => {
          if (res.status === 200) {
            console.log(res)
            this.data[0].childList[1].childList = [...res.data]
          } else {
            this.$notify.error({ title: res.message })
          }
        }).catch(err => {
          console.log(err)
          this.$notify.error({ title: '请刷新重试' })
        })
      },
      addItem (type) {
        if (type === 'shop') {

        } else {

        }
      },
      deleteItem (data) {
        console.log(data)
        this.$confirm(`确认删除 ${data.name} 吗？`)
          .then(confirm => {
            if (confirm) {
              this.loading = true
              warehouseApi.del({ id: data.id }).then(res => {
                if (res.status === 200) {
                  this.loading = false
                  this.$notify({
                    title: '删除成功',
                    type: 'success'
                  })
                  this.getTreeData()
                }
              })
            }
          })
      },
      editItem (item) {

      }
    }
  }
</script>

<style>
    /* @import "../less/layout.css"; */
    .clearfix:before,
    .clearfix:after {
        display: table;
        content: "";
    }

    .clearfix:after {
        clear: both;
    }

    .custom-tree-node {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 12px;
        padding-right: 8px;
        padding-bottom: 5px;
    }

    /*bymyself*/

    .el-transfer__buttons {
        padding: 0 15px;
    }

    #depManagement .dialog-footer {
        float: right;
        margin: 25px 0px 0px 0px;
    }

    .el-transfer-panel__item {
        display: block;
    }

    #showEmployees .el-dialog {
        width: 800px;
        min-height: 430px;
    }

    .fontStyle {
        font-size: 12px;
        margin-right: 10px;
        font-weight: bold;
    }

    .el-tree-node {
        padding-top: 5px;
    }

    .depTypeStyle {
        display: inline-block;
        width: 18px;
        height: 18px;
        line-height: 18px;
        border-radius: 11px;
        padding-left: 3px;
        background-color: #FE714D;
        color: #FFFFFF;
    }

    .depLevelStyle {
        display: inline-block;
        width: 15px;
        height: 15px;
        line-height: 15px;
        border-radius: 10px;
        padding-left: 3px;
        border: 1px solid #A24BA6;
        color: #A24BA6;
    }

    .leveloffset {
        padding-left: 5px;
    }

    /* 添加人员弹框 */
    div.el-dialog {
        width: 670px;
    }

    div.el-transfer-panel {
        width: 250px;
    }

    #depManagement .el-dialog__footer {
        border: 0;
    }
</style>
