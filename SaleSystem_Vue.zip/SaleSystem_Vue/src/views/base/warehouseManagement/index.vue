<template>
    <d2-container better-scroll class="layout">
        <!-- 表单-数据筛选 -->
        <el-card class="">
            <el-form :inline="true" :model="query" class="demo-ruleForm" id="searchData" label-width="100px"
                     ref="query">
                <el-button @click="delAllSelection" size="small" style="float: left;margin-right: 50px" type="danger">
                    <i class="iconfont iconfont-smallshanchu"/>&nbsp;批量删除
                </el-button>
                <el-form-item label="编号" prop="id">
                    <el-input placeholder="仓库编号" v-model="query.id"/>
                </el-form-item>
                <el-form-item label="名称" prop="name">
                    <el-input placeholder="仓库名称" v-model="query.name"/>
                </el-form-item>
                <el-form-item label="地址" prop="address">
                    <el-input placeholder="仓库地址" v-model="query.address"/>
                </el-form-item>
                <el-form-item>
                    <el-button @click="fetchData()" size="small" style="margin-left: 1rem" type="primary"><i
                            class="iconfont iconfont-sousuo"/>&nbsp;查询
                    </el-button>
                    <el-button @click="resetForm('query')" size="small" style="margin-left: 2rem"><i
                            class="iconfont iconfont-zhongzhi"/>&nbsp;重置
                    </el-button>
                </el-form-item>
                <el-button @click="addItem()" id="addButton" size="small" style="float: right;" type="primary">
                    <i class="iconfont iconfont-add-fill"/>&nbsp;添加
                </el-button>
            </el-form>
            <el-table
                    :data="tableData"
                    :default-sort="{prop: 'id'}"
                    @selection-change="handleSelectionChange"
                    border
                    size="small"
                    stripe
                    style="width: 100%"
                    v-loading="loading"
            >

                <el-table-column align="center" fixed type="selection"/>
                <el-table-column
                        label="id"
                        prop="id"
                        style="margin-left: 1px">
                </el-table-column>
                <el-table-column
                        label="名称"
                        prop="name">
                </el-table-column>
                <el-table-column
                        label="电话"
                        prop="tel"
                >
                </el-table-column>
                <el-table-column
                        label="地址"
                        prop="address">
                </el-table-column>
                <el-table-column align="center" label="操作" width="300">
                    <template slot-scope="scope">
                        <el-link :underline="false" @click="editItem(scope.$index, scope.row)"
                                 style="color: #409EFF;">
                            <i class="iconfont iconfont-bianji1"/> 编辑
                        </el-link>
                        <el-link :style="{'color':'#F56C6C',marginLeft: '50px'}"
                                 :underline="false"
                                 @click="deleteItem(scope.$index, scope.row)">
                            <i class="iconfont iconfont-shanchu"/> 删除
                        </el-link>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                    :current-page="query.pageIndex"
                    :page-size="query.pageSize"
                    :page-sizes="[10, 15, 30]"
                    :total="query.pageTotal"
                    @current-change="handlePageChange"
                    @size-change="handleSizeChange"
                    layout="total, sizes, prev, pager, next">
            </el-pagination>
        </el-card>
        <el-dialog :title="dialogType==='edit'?`编辑${title}`:`新增${title}`" :visible.sync="dialogVisible" append-to-body>
            <el-form :model="dialogData" :rules="dialogFormRules" ref="dialogData">
                <el-form-item label="仓库名" label-width="13%" prop="name">
                    <el-input v-model="dialogData.name"/>
                </el-form-item>
                <el-form-item label="仓库地址" label-width="13%" prop="address">
                    <el-input v-model="dialogData.address"/>
                </el-form-item>
                <el-form-item label="仓库电话" label-width="13%" prop="tel">
                    <el-input v-model="dialogData.tel"/>
                </el-form-item>
            </el-form>
            <div class="dialog-footer" slot="footer">
                <el-button @click="submit()" type="primary">确 定</el-button>
                <el-button @click="dialogVisible = false">取 消</el-button>
            </div>
        </el-dialog>
    </d2-container>
</template>

<script>
  import pagination from '@/components/pagination'

  const warehouseApi = require('@/api/warehouse')
  export default {
    components: { pagination }, // 组件化
    data () {
      return {
        title: '仓库',
        loadingCount: 0,
        multipleSelection: [],
        delList: [],
        tableData: [],
        dialogType: 'add',
        dialogVisible: false,
        dialogFormRules: {
          name: [{ required: true, message: '请填写商品名称', trigger: 'blur' }],
          tel: [{ required: true, message: '请填写商品单位', trigger: 'blur' }],
          address: [{ required: true, message: '请填写商品类型', trigger: 'blur' }],
        },
        dialogData: {
          status: 2,
          id: '',
          name: '',
          tel: '',
          address: ''
        },
        query: {
          status: 2,
          id: '',
          name: '',
          address: '',
          pageIndex: 0,
          pageSize: 10,
          spare: '',
          pageTotal: 0
        }
      }
    },
    created () {
      this.fetchData()
    },
    methods: {
      fetchData () {
        this.loadingCount++
        warehouseApi.getList(this.query).then(res => {
          if (res.status === 200) {
            this.tableData = res.data
            this.query.pageTotal = res.pageTotal
          }
          if (res.status === 400) {
            this.tableData = []
            this.query.pageTotal = res.pageTotal
          }
          this.loadingCount--
        })
      },
      indexMethod (index) {
        index = index + 1
        if (this.query.pageIndex === 1) {
          return index
        } else {
          return index + (this.query.pageIndex - 1) * (this.query.pageSize)
        }
      },
      resetForm () {
        this.query.address = ''
        this.query.id = ''
        this.query.pageIndex = 1
        this.fetchData()
      },
      deleteItem (index, item) {
        this.$confirm(`确认删除 ${item.name} 吗？`)
          .then(confirm => {
            if (confirm) {
              console.log(item.id)
              this.loadingCount++
              warehouseApi.del({ id: item.id }).then(res => {
                if (res.status === 200) {
                  this.loadingCount--
                  this.$notify({
                    title: '删除成功',
                    type: 'success'
                  })
                  this.fetchData()
                }
              })
            }
          })
        console.log(index, item)
      },
      delAllSelection () {
        const _this = this
        const length = this.multipleSelection.length
        let str = ''
        let ids = []
        this.delList = this.delList.concat(this.multipleSelection)
        for (let i = 0; i < length; i++) {
          let id = this.multipleSelection[i].id
          ids.push(id)
          str += id + ' '
        }
        //console.log(ids);
        this.$confirm('确定要删除' + str + '吗？', '提示', {
          type: 'warning'
        }).then((confirm) => {
          if (confirm) {
            str = ''
            for (let i = 0; i < length; i++) {
              let id = ids[i]
              str += id + ' '
              _this.loadingCount++
              warehouseApi.del({ id: id }).then(res => {
                this.loadingCount--
              })
            }
            this.multipleSelection = []
            this.fetchData()
            this.$message.success('删除:' + str)
          }
        })

      },
      editItem (index, item) {
        this.dialogType = 'edit'
        this.dialogData = {
          status: 2,
          id: item.id,
          name: item.name,
          tel: item.tel,
          address: item.address
        }
        this.dialogVisible = true
      },
      // 添加数据
      addItem () {
        this.dialogType = 'add'
        this.dialogData = {
          status: 2,
          name: '',
          tel: '',
          category: ''
        }
        this.dialogVisible = true
      },
      handlePageChange (val) {
        this.$set(this.query, 'pageIndex', val)
        this.fetchData()
      },
      submit () {
        if (this.dialogType === 'add') {
          console.log(this.dialogData)
          warehouseApi.add(this.dialogData).then(res => {
            if (res.status === 200) {
              this.$notify({
                title: '添加成功',
                type: 'success'
              })
              this.fetchData()
              this.dialogVisible = false
            }
          })
        } else {
          warehouseApi.update(this.dialogData).then(res => {
            if (res.status === 200) {
              this.$notify({
                title: '编辑成功',
                type: 'success'
              })
              this.fetchData()
              this.dialogVisible = false
            }
          })
        }
      },
      handleSizeChange (val) {
        this.query.pageSize = val
        this.query.pageIndex = 1
        this.handlePageChange()
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      }
    },
    computed: {
      loading: function () {
        return this.loadingCount > 0
      }
    },
  }

</script>

<style>
    /* 后加 */

    .el-table thead.is-group th {
        background: none;
    }

    .el-table thead.is-group tr:first-of-type th:first-of-type {
        border-bottom: none;
    }

    .el-table thead.is-group tr:first-of-type th:first-of-type:before {
        content: '';
        position: absolute;
        width: 1px;
        top: 0;
        left: 0;
        background-color: grey;
        opacity: 0.3;
        display: block;
        transform: rotate(-53deg); /*这里需要自己调整，根据线的位置*/
        transform-origin: top;
    }

    .el-table thead.is-group tr:last-of-type th:first-of-type:before {
        content: '';
        position: absolute;
        width: 1px;
        bottom: 0;
        right: 0;
        background-color: grey;
        opacity: 0.3;
        display: block;
        transform: rotate(-54deg); /*这里需要自己调整，根据线的位置*/
        transform-origin: bottom;
        /* // background:red; */
    }


</style>
