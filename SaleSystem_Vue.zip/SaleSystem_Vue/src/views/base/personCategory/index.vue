<template>
    <div class="layout" id="roleManagement">
        <!-- 表单-数据筛选 -->
        <el-card class="box-card">
            <div class="clearfix" slot="header">
                <span class="title">数据筛选</span>
            </div>
            <el-form :inline="true" :model="query" class="demo-ruleForm" id="searchData" label-width="100px"
                     ref="query">
                <el-form-item label="输入查询" prop="roleName">
                    <el-input placeholder="角色名称" v-model="query.roleName"/>
                </el-form-item>
                <el-form-item label="启用状态" prop="roleState">
                    <el-select placeholder="全部" v-model="query.roleState">
                        <el-option label="全部" value=""/>
                        <el-option label="启动" value="1"/>
                        <el-option label="停用" value="0"/>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button @click="search('query')" size="small" type="primary"><i
                            class="iconfont iconfont-sousuo"/> 查询
                    </el-button>
                    <el-button @click="resetForm('query')" size="small"><i class="iconfont iconfont-zhongzhi"/>重置
                    </el-button>
                </el-form-item>
                <!--                <el-button size="small" type="primary" @click="exportExcel">-->
                <!--                    <d2-icon name="download"/>-->
                <!--                    导出 Excel-->
                <!--                </el-button>-->
            </el-form>

        </el-card>
        <!-- 数据列表---table -->
        <el-card class="box-card">
            <div class="clearfix" slot="header">
                <span class="title">数据列表</span>
                <el-button @click="showAddModal()" id="addButton" size="small" style="float: right;" type="primary"><i
                        class="iconfont iconfont-tianjia"/>&nbsp;新增角色
                </el-button>
            </div>
            <el-table
                    :data="tableData"
                    :default-sort="{prop: 'date', order: 'descending'}"
                    border
                    stripe
                    style="width: 100%"
                    v-loading="loading"
            >
                <el-table-column
                        label="序号"
                        prop="id"
                        type="index"
                        width="50"
                >
                </el-table-column>
                <el-table-column
                        label="角色名称"
                        prop="type"
                >
                </el-table-column>
                <el-table-column
                        label="角色描述"
                        prop="spare"
                >
                </el-table-column>
                <el-table-column align="center" label="操作" width="350">
                    <template slot-scope="scope">
                        <el-link :underline="false" @click="roleRightsSetting(scope.$index, scope.row)"
                                 style=" color: #409EFF;" v-if="scope.row.roleState!==2">
                            <i class="fa fa-gear"/> 权限设置
                        </el-link>
                        <el-link :underline="false" @click="showEditModal(scope.$index, scope.row)"
                                 style="margin-left: 20px; color: #409EFF;">
                            <i class="iconfont iconfont-bianji"/> 编辑
                        </el-link>
                        <el-link :underline="false" @click="deleteRole(scope.$index, scope.row)"
                                 style="margin-left: 20px; color: #409EFF;" v-if="scope.row.roleState!==2">
                            <i class="iconfont iconfont-chushaixuanxiang"/> 删除
                        </el-link>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                    :current-page="query.pageIndex"
                    :page-size="query.pageSize"
                    :page-sizes="[10, 15, 30]"
                    :total="query.pageTotal"
                    @current-change="handlePageChange"
                    @size-change="handleSizeChange"
                    layout="total, sizes, prev, pager, next">
            </el-pagination>
        </el-card>
        <!-- 新增角色弹框dialog -->
        <el-dialog :title="dialogType==='edit'?'修改角色':'新增角色'" :visible.sync="addRoleDialogVisible">
            <el-form :model="dialogData" :rules="dialogFormRules" ref="dialogData">
                <el-form-item :label-width="formLabelWidth" label="角色名称" prop="roleName">
                    <el-input v-model="dialogData.roleName"/>
                </el-form-item>
                <el-form-item :label-width="formLabelWidth" label="角色描述" prop="roleNote">
                    <el-input type="textarea" v-model="dialogData.roleNote"></el-input>
                </el-form-item>
            </el-form>
            <div class="dialog-footer" slot="footer">
                <el-button @click="addOrUpdateDialogSubmit()" type="primary">确 定</el-button>
                <el-button @click="addRoleDialogVisible = false">取 消</el-button>
            </div>
        </el-dialog>
        <!-- 查看部门人员 dialog-->
        <el-dialog :before-close="employeesViewCancel" :visible.sync="employeesViewDialogVisible" id="showEmployees"
                   title="部门人员">
            <el-table
                    :data="showEmployeesData"
                    stripe
                    style="width: 100%">
                <el-table-column
                        label="员工工号"
                        prop="empNo"
                >
                </el-table-column>
                <el-table-column
                        label="姓名"
                        prop="empName"
                >
                </el-table-column>
                <el-table-column
                        label="手机号码"
                        prop="empPhone">
                </el-table-column>
                <el-table-column
                        label="备注"
                        prop="empNote">
                </el-table-column>
            </el-table>
            <pagination
                    @paginationMessage="getShowRolePaginationMessage"
                    v-bind:message="empNumquery"
            />
        </el-dialog>
        <!-- 分配页面权限和按钮权限 -->
        <el-dialog :visible.sync="roleFunctionSettingDialogVisible" title="页面权限分配" top="12vh" width="55%">
            <role-function-setting @dialogVisibile="changeDialogVisible"
                                   v-bind:roleInfo="roleInfo"></role-function-setting>
        </el-dialog>
    </div>
</template>

<script>
  import pagination from '@/components/pagination'
  import roleFunctionSetting from '@/components/funcRightsSetting'

  const roleManagementApi = require('@/api/roleManagement')
  export default {
    components: { pagination, roleFunctionSetting }, // 组件化
    data () {
      return {
        roleFunctionSettingDialogVisible: false,
        roleInfo: {
          roleId: '',
          roleName: ''
        },
        // 传输给后台的值
        query: {
          id: '',
          name: '',
          pageIndex: 0,
          pageSize: 10,
          spare: '',
          pageTotal: 0
        },
        // 查看角色人员时想后台传输的分页数据
        empNumquery: {
          roleId: '',
          curr: 1,
          size: 5,
          total: null
        },
        value: [],
        addPersonDialogVisible: false,
        addRoleDialogVisible: false,
        employeesViewDialogVisible: false,
        formLabelWidth: '100px',
        tableData: [],
        showEmployeesData: [],
        selectForm: {
          name: '',
          state: ''
        },
        dialogData: {
          roleName: null,
          roleNote: null,
          roleId: null
        },
        dialogType: 'add',
        dialogFormRules: {
          roleName: [{ required: true, message: '请填写角色名称', trigger: 'blur' }]
        },
        loading: false

      }
    },
    created () {
      this.getTableData()
    },
    methods: {
      // 获取表单数据
      getTableData () {
        this.loading = true
        roleManagementApi.getSysRoleList(this.query).then(res => {
          if (res.status === 200) {
            this.tableData = res.data
            this.loading = false
            // this.query.size = res.data.pageSize
            this.query.pageTotal = res.pageTotal
            console.log(res)
            // this.query.curr = res.data.currentPage
          } else {
            this.$notify.error({ title: res.message })
          }
        }).catch(res => {
          this.$notify.error({ title: '请刷新重试' })
        })
      },
      // 搜索，提交表单数据
      search (formName) {
        // var formData = JSON.stringify(this.ruleForm);
        if (this.query.roleName == null && this.query.roleState == null) {
          this.$message({
            message: '请输入查询条件！',
            type: 'warning'
          })
        } else {
          this.query.curr = 1
          this.query.size = 5
          this.query.total = null
          this.getTableData()
        }
      },
      // 表格序号
      indexMethod (index) {
        index = index + 1
        if (this.query.curr === 1) {
          return index
        } else {
          return index + (this.query.curr - 1) * (this.query.size)
        }
      },
      // 接收子组件分页的数据--刷新整个表格
      getPaginationMessage (message) {
        // this.tableData = message;
        this.query = message
        this.getTableData()
      },
      // 接收子组件分页的数据--刷新角色
      getShowRolePaginationMessage (message) {
        // console.log(message)
        this.empNumquery = message
        this.showEmployeesView()
      },
      // ----------------以上是通用函数-------------------

      changeUseState (row) {
        this.$alert('确定要停用该角色吗？', '提示信息', {
          confirmButtonText: '确定',
          callback: action => {
            row.roleState = 1 ^ row.roleState
            roleManagementApi.deleteSysRole(row).then((res) => {
              if (res.status === 200) {
                this.$notify.info({
                  title: res.message
                })
                this.getTableData()
              } else {
                this.$notify.error({
                  title: res.message
                })
              }
            }).catch(err => {
              console.log(err)
              this.$message.error('请刷新重试')
            })
          }
        })
      },
      // 添加数据
      showAddModal () {
        this.dialogType = 'add'
        this.dialogData = {
          roleName: '',
          roleNote: ''
        }
        this.addRoleDialogVisible = true
      },
      showEditModal (index, row) {
        this.dialogType = 'edit'
        this.dialogData = {
          roleId: row.roleId,
          roleName: row.roleName,
          roleNote: row.roleNote
        }
        this.addRoleDialogVisible = true
      },
      submitForInsertRole () {
        this.$refs.dialogData.validate(valid => {
          if (valid) {
            roleManagementApi.insertSysRole(this.dialogData).then((res) => {
              if (res.status === 200) {
                this.addRoleDialogVisible = false
                // 清空表单
                this.$nextTick(() => {
                  this.$refs['dialogData'].resetFields()
                })
                this.getTableData()
                this.$notify.info({
                  title: res.message
                })
              } else {
                this.$notify.error({
                  title: res.message
                })
              }
            }).catch(err => {
              console.log(err)
              this.$message.error('请刷新重试')
            })
          } else {
            return false
          }
        })
      },
      submitForUpdateRole () {
        this.$refs.dialogData.validate(valid => {
          if (valid) {
            roleManagementApi.updateSysRole(this.dialogData).then((res) => {
              if (res.status === 200) {
                this.addRoleDialogVisible = false
                // 清空表单
                this.$nextTick(() => {
                  this.$refs['dialogData'].resetFields()
                })
                this.getTableData()
                // this.$notify.success({
                //     title: res.message
                // });
              } else {
                this.$notify.error({
                  title: res.message
                })
              }
            }).catch(err => {
              console.log(err)
              this.$message.error('请刷新重试')
            })
          } else {
            return false
          }
        })
      },
      // 提交弹出框数据
      addOrUpdateDialogSubmit () {
        // var dialogData=JSON.stringify(this.dialogData); //将数据变成字符串
        if (this.dialogType === 'edit') {
          this.submitForUpdateRole()
        }
        if (this.dialogType === 'add') {
          this.submitForInsertRole()
        }
      },
      // 删除角色
      deleteRole (index, row) {
        this.$confirm('是否删除该角色?', '提示信息', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          roleManagementApi.deleteSysRole({ 'roleId': row.roleId, 'roleState': 2 }).then((res) => {
            if (res.status === 200) {
              // this.$notify.success({
              //     title: res.message
              // });
              this.getTableData()
            } else {
              this.$notify.error({
                title: res.message
              })
            }
          }).catch(err => {
            console.log(err)
            this.$message.error('请刷新重试')
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      // 设置权限
      roleRightsSetting (index, row) {
        this.roleInfo.roleId = row.roleId
        this.roleInfo.roleName = row.roleName
        this.roleFunctionSettingDialogVisible = true
      },
      changeDialogVisible (isVisible) {
        this.roleFunctionSettingDialogVisible = isVisible
      },
      // 查看
      showEmployeesView (index, row) {
        if (row) {
          this.empNumquery.roleId = row.roleId
        }
        // this.empNumquery.total = null; //每次点击total设置成null
        this.employeesViewDialogVisible = true
        roleManagementApi.getSysRoleListIsChoice(this.empNumquery).then((res) => {
          if (res.status === 200) {
            this.showEmployeesData = res.data.list
            this.empNumquery.size = res.data.pageSize
            this.empNumquery.total = res.data.pageTotal
            this.empNumquery.curr = res.data.currentPage
          } else {
            this.$notify.error({
              title: res.message
            })
          }
        }).catch(err => {
          console.log(err)
          this.$message.error('请刷新重试')
        })
      },
      employeesViewCancel () {
        this.employeesViewDialogVisible = false
        this.empNumquery.total = null
        this.empNumquery.curr = 1
        this.empNumquery.size = 5
      },
      resetForm (ruleForm) {
        this.$refs[ruleForm].resetFields()
        this.query.curr = 1
        this.query.size = 5
        this.getTableData()
      },
      handlePageChange (val) {
        this.$set(this.query, 'pageIndex', val)
        this.fetchData()
      },
      handleSizeChange (val) {
        this.query.pageSize = val
        this.query.pageIndex = 1
        this.handlePageChange()
      },
      // exportExcel () {
      //   this.$export.excel({
      //     columns: this.tableData.columns,
      //     data: this.tableData.data,
      //     header: '导出 Excel',
      //     merges: ['A1', 'E1']
      //   })
      //     .then(() => {
      //       this.$message('导出表格成功')
      //     })
      // }

    }
  }

</script>

<style lang="less">

    .tooltiptext {
        position: relative;
        top: -10px;
        right: -15px;
        font-size: 14px;
        color: #409EFF;
    }

    .text {
        font-size: 14px;
    }

    .item {
        margin-bottom: 18px;
    }

    .clearfix:before,
    .clearfix:after {
        display: table;
        data: "";
    }

    .clearfix:after {
        clear: both
    }

    .el-dialog {
        width: 40%;
        min-height: 240px;
    }

    .el-dialog__footer {
        border-top: 1px solid #ddd;
    }

    .el-dialog__header {
        border-bottom: 1px solid #ddd;
    }

    /* 查看人员 */
    #showEmployees .el-dialog {
        width: 800px;
        min-height: 430px;
    }

    #roleManagement {
        .el-dialog__body {
            padding: 10px 20px 50px 20px;
        }
    }
</style>
