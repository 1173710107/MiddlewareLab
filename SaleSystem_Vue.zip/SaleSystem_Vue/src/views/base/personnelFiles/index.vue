<template>
    <d2-container better-scroll class="layout" id="empManagement">
        <!-- 表单-数据筛选 -->
        <el-card class="box-card">
            <div class="clearfix" slot="header">
                <span class="title">数据筛选</span>
            </div>
            <el-form :inline="true" :model="query" class="demo-ruleForm" id="searchData" label-width="100px"
                     ref="query">
                <el-form-item label="输入查询" prop="empNoName">
                    <el-input placeholder="工号/姓名" v-model="query.name"></el-input>
                </el-form-item>
                <el-form-item label="员工角色" prop="type">
                    <el-select placeholder="全部" v-model="query.roleId">
                        <el-option
                                :key="index"
                                :label="opt.roleName"
                                :value="opt.roleId"
                                v-for="(opt,index) in roleOpts">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="所属部门" prop="departId">
                    <el-cascader
                            :options="departOpts"
                            :props="{ checkStrictly: true }"
                            :show-all-levels="false"
                            clearable
                            placeholder="所有部门"
                            ref="depCascade"
                            v-model="query.id">
                    </el-cascader>
                </el-form-item>
                <el-form-item>
                    <el-button @click="search()" size="small" type="primary"><i class="iconfont icon-sousuo"/> 查询
                    </el-button>
                    <el-button @click="resetForm('query')" size="small"><i class="iconfont icon-zhongzhi"/>重置
                    </el-button>
                </el-form-item>
            </el-form>
        </el-card>
        <!-- 数据列表---table -->
        <el-card class="box-card topGutter">
            <div class="clearfix" slot="header">
                <span class="title">数据列表</span>
                <el-button @click="showAddModal()" id="addButton" size="small" style="float: right;" type="primary"><i
                        class="iconfont icon-tianjia"/>&nbsp;添加
                </el-button>
            </div>
            <el-table
                    :data="tableData"
                    :default-sort="{prop: 'id', order: 'descending'}"
                    border
                    stripe
                    style="width: 100%"
                    v-loading="loading">
                <el-table-column align="center" fixed type="selection"></el-table-column>
                <el-table-column
                        :index="indexMethod"
                        label="序号"
                        type="index"
                        width="50"
                >
                </el-table-column>
                <el-table-column
                        label="工号"
                        prop="id"
                >
                </el-table-column>
                <el-table-column
                        label="员工姓名"
                        prop="name">
                </el-table-column>
                <el-table-column
                        label="用户名"
                        prop="username"
                >
                </el-table-column>
                <el-table-column
                        label="所属部门id"
                        prop="warehouseid">
                </el-table-column>
                <el-table-column
                        label="员工角色"
                        prop="type">
                </el-table-column>
                <el-table-column
                        label="手机"
                        prop="tel">
                </el-table-column>
                <el-table-column label="操作" width="300">
                    <template slot-scope="scope">
                        <el-link :underline="false" @click="showUpdateModal(scope.$index, scope.row)"
                                 style="margin-left: 60px; color: #409EFF;">
                            <i class="iconfont iconfont-bianji1"/> 编辑
                        </el-link>
                        <el-link :style="{'color':scope.row.status===1?'#F56C6C':'#67C23A',marginLeft: '50px'}"
                                 :underline="false"
                                 @click="isFrozenChanged(scope.$index, scope.row)" v-if="scope.row.empState!==2">
                            <i class="iconfont iconfont-jinyong"/> {{scope.row.status===2?'冻结':'取消冻结'}}
                        </el-link>
                    </template>
                </el-table-column>
            </el-table>
            <pagination
                    @paginationMessage="getPaginationMessage"
                    v-bind:message="query"
            />
        </el-card>

    </d2-container>
</template>

<script>
  import pagination from '@/components/pagination'

  const empApi = require('@/api/person')
  export default {
    components: { pagination }, // 组件化
    data () {
      return {
        tableData: [],
        loading: false,
        // 传输给后台的值
        query: {
          roleId: null,
          id: null,
          name: null,
          curr: 1,
          size: 5,
          total: 27
        }
      }
    },
    created () {
      this.fetchData()
    },
    methods: {
      fetchData () {
        // 获取列表数据
        this.loading = true
        empApi.getList(this.query).then(res => {
          if (res.status === 200) {
            this.loading = false
            this.tableData = res.data
          } else {
            this.$notify.error({ title: res.message })
          }
        }).catch(err => {
          console.log(err)
          this.$notify.error({ title: '请刷新重试' })
        })
      },
      // 获取角色下拉数据
      getRoleOpts () {
        empApi.getSysRoleSelect({}).then((res) => {
          if (res.status === 200) {
            // console.log(res.data);
            this.roleOpts = res.data
            this.roleOpts.unshift({ 'roleId': null, 'roleName': '全部' })
          } else {
            this.$notify.error({ title: res.message })
          }
        }).catch(err => {
          console.log(err)
          this.$notify.error({ title: '请刷新重试' })
        })
      },
      // 获取部门下拉数据
      getDepartOpts () {
        empApi.getSysDepartAll({}).then((res) => {
          if (res.status === 200) {
            this.departOpts = JSON.parse(JSON.stringify(res.data).replace(/childList/g, 'children'))
            this.departOpts = JSON.parse(JSON.stringify(this.departOpts).replace(/departName/g, 'label'))
            this.departOpts = JSON.parse(JSON.stringify(this.departOpts).replace(/departId/g, 'value'))
          } else {
            this.$notify.error({ title: res.message })
          }
        }).catch(err => {
          console.log(err)
          this.$notify.error({ title: '请刷新重试' })
        })
      },

      // 批量导入跳转
      batchImport () {
        this.$router.push('/platformManagement/batchImport')
      },
      // 添加员工
      showAddModal () {
        this.$router.push({
          path: '/platformManagement/addOrEditEmployees',
          query: {
            type: 'add'
          }
        })
      },
      // 编辑员工
      showUpdateModal (index, row) {
        this.$router.push({
          path: '/platformManagement/addOrEditEmployees',
          query: {
            type: 'edit',
            empId: row.empId
            // ...row
          }
        })
      },

      // 冻结员工账号
      isFrozenChanged (index, row) {
        var isFrozen = {
          'empState': 1 ^ row.empState,
          'empId': row.empId
        }
        this.$alert('是否要冻结该员工账号', '提示信息', {
          confirmButtonText: '确定',
          callback: action => {
            empApi.getSysEmpState(isFrozen).then((res) => {
              if (res.status === 200) {
                // this.$notify.success({ title: res.message });
                this.fetchData()
              } else {
                this.$notify.error({ title: res.message })
              }
            }).catch(err => {
              console.log(err)
              this.$notify.error({ title: '请刷新重试' })
            })
          }
        })
      },
      // 搜索，提交表单数据
      search () {
        // 判断是否有筛选值
        if (this.query.roleId == null && this.query.id == null && this.query.name == null) {
          this.$message({
            message: '请输入查询条件！',
            type: 'warning'
          })
        } else {
          this.query.curr = 1
          this.query.size = 5
          if (this.$refs.depCascade.getCheckedNodes().length > 0) {
            this.query.id = this.$refs.depCascade.getCheckedNodes()[0].value
          }
          this.fetchData(this.query)
        }
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
        this.query.curr = 1
        this.query.size = 5
        this.fetchData()
      },
      // 接收子组件分页的数据--刷新整个表格
      getPaginationMessage (message) {
        this.query = message
        this.fetchData()
      },
      // 表格序号
      indexMethod (index) {
        index = index + 1
        if (this.query.curr === 1) {
          return index
        } else {
          return index + (this.query.curr - 1) * (this.query.size)
        }
      }
    }
  }

</script>

<style>
    .clearfix:before,
    .clearfix:after {
        display: table;
        data: "";
    }

    .clearfix:after {
        clear: both
    }

    /* 后加 */

    .el-table thead.is-group th {
        background: none;
    }

    .el-table thead.is-group tr:first-of-type th:first-of-type {
        border-bottom: none;
    }

    .el-table thead.is-group tr:first-of-type th:first-of-type:before {
        data: '';
        position: absolute;
        width: 1px;
        height: 75px; /*这里需要自己调整，根据td的宽度和高度*/
        top: 0;
        left: 0;
        background-color: grey;
        opacity: 0.3;
        display: block;
        transform: rotate(-53deg); /*这里需要自己调整，根据线的位置*/
        transform-origin: top;
    }

    .el-table thead.is-group tr:last-of-type th:first-of-type:before {
        data: '';
        position: absolute;
        width: 1px;
        height: 75px; /*这里需要自己调整，根据td的宽度和高度*/
        bottom: 0;
        right: 0;
        background-color: grey;
        opacity: 0.3;
        display: block;
        transform: rotate(-54deg); /*这里需要自己调整，根据线的位置*/
        transform-origin: bottom;
        /* // background:red; */
    }

</style>
