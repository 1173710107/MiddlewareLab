<template>
    <d2-container better-scroll class="layout" id="empManagement">
        <!-- 表单-数据筛选 -->
        <el-card class="">

            <el-form :inline="true" :model="query" class="demo-ruleForm" id="searchData" label-width="100px"
                     ref="query">
                <el-button @click="showAddModal()" size="small" style="float: left;margin-right: 50px" type="primary">
                    <i class="iconfont icon-tianjia"></i>&nbsp;批量删除
                </el-button>

                <el-form-item label="输入查询" prop="empNoName">
                    <el-input placeholder="货品名称" v-model="query.name"></el-input>
                </el-form-item>
                <el-form-item label="会员类型" prop="roleId">
                    <el-select placeholder="全部" v-model="query.roleId">
                        <el-option
                                :key="index"
                                :label="opt.roleName"
                                :value="opt.roleId"
                                v-for="(opt,index) in roleOpts">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="所属门店" prop="departId">
                    <el-cascader
                            :options="departOpts"
                            :props="{ checkStrictly: true }"
                            :show-all-levels="false"
                            clearable
                            placeholder="所有门店"
                            ref="depCascader"
                            v-model="query.id">
                    </el-cascader>
                </el-form-item>
                <el-form-item>
                    <el-button @click="search()" size="small" type="primary"><i class="iconfont icon-sousuo"></i> 查询
                    </el-button>
                    <el-button @click="resetForm('query')" size="small"><i class="iconfont icon-zhongzhi"></i>重置
                    </el-button>
                </el-form-item>
                <el-button @click="showAddModal()" id="addButton" size="small" style="float: right;" type="primary"><i
                        class="iconfont icon-tianjia"></i>&nbsp;添加
                </el-button>

            </el-form>

            <el-table
                    :data="tableData"
                    :default-sort="{prop: 'id', order: 'descending'}"
                    border
                    size="small"
                    stripe
                    style="width: 100%"
                    v-loading="loading"
            >

                <el-table-column align="center" fixed type="selection" width="66"></el-table-column>
                <el-table-column
                        :index="indexMethod"
                        label="序号"
                        type="index"
                        width="50"
                >
                </el-table-column>
                <!--<el-table-column
                        prop="jigou"
                        label="所属机构"
                >
                </el-table-column>-->
                <el-table-column
                        label="调货单id"
                        prop="id"
                        width="80"
                >
                </el-table-column>
                <el-table-column
                        label="店长id"
                        prop="bossid">
                </el-table-column>
                <el-table-column
                        label="经理id"
                        prop="managerid">
                </el-table-column>
                <el-table-column
                        label="出库管理员id"
                        prop="outpersonid">
                </el-table-column>
                <el-table-column
                        label="进库管理员id"
                        prop="inpersonid">
                </el-table-column>
                <el-table-column
                        label="出库仓库id"
                        prop="outwarehouseid">
                </el-table-column>
                <el-table-column
                        label="进库仓库id"
                        prop="inwarehouseid">
                </el-table-column>
                <el-table-column
                        label="状态"
                        prop="status">
                </el-table-column>

                <el-table-column
                        label="时间"
                        prop="time">
                </el-table-column>

                <el-table-column label="操作" width="300">
                    <template slot-scope="scope">
                        <el-link :underline="false" @click="showUpdateModal(scope.$index, scope.row)"
                                 style=" color: #409EFF;">
                            <i class="iconfont iconfont-bianji1"></i> 编辑
                        </el-link>
                        <el-link :style="{'color':scope.row.empState===1?'#F56C6C':'#67C23A',marginLeft: '50px'}"
                                 :underline="false"
                                 @click="isFrozenChanged(scope.$index, scope.row)" v-if="scope.row.empState!==2">
                            <i class="iconfont iconfont-jinyong"></i> {{scope.row.empState===1?'删除':'撤销'}}
                        </el-link>
                    </template>
                </el-table-column>
            </el-table>
            <pagination
                    @paginationMessage="getPaginationMessage"
                    v-bind:message="query"
            />
        </el-card>

    </d2-container>
</template>

<script>
  import pagination from '@/components/pagination'

  const empApi = require('@/api/person')
  export default {
    components: { pagination }, // 组件化
    data () {
      return {
        query: {
          category: '',
          id: '',
          name: '',
          pageIndex: '',
          pageSize: '',
          spare: '',
          unit: ''
        }
      }
    },
    created () {

    },
    methods: {}
  }

</script>

<style>
    /* @import "../less/layout.css"; */
    .tooltiptext {
        position: relative;
        top: -10px;
        right: -15px;
        font-size: 14px;
        color: #409EFF;
    }

    .text {
        font-size: 14px;
    }

    .item {
        margin-bottom: 18px;
    }

    .clearfix:before,
    .clearfix:after {
        display: table;
        content: "";
    }

    .clearfix:after {
        clear: both
    }

    /* 后加 */

    .el-table thead.is-group th {
        background: none;
    }

    .el-table thead.is-group tr:first-of-type th:first-of-type {
        border-bottom: none;
    }

    .el-table thead.is-group tr:first-of-type th:first-of-type:before {
        content: '';
        position: absolute;
        width: 1px;
        top: 0;
        left: 0;
        background-color: grey;
        opacity: 0.3;
        display: block;
        transform: rotate(-53deg); /*这里需要自己调整，根据线的位置*/
        transform-origin: top;
    }

    .el-table thead.is-group tr:last-of-type th:first-of-type:before {
        content: '';
        position: absolute;
        width: 1px;
        bottom: 0;
        right: 0;
        background-color: grey;
        opacity: 0.3;
        display: block;
        transform: rotate(-54deg); /*这里需要自己调整，根据线的位置*/
        transform-origin: bottom;
        /* // background:red; */
    }

</style>
