// 菜单 侧边栏
export default [
  { path: '/index', title: '首页', icon: 'home' },
  {
    title: '基础档案',
    icon: 'iconfont-jichuziyuan',
    children: [
      {
        title: '部门设置',
        icon: 'iconfont-bumen',
        path: '/base/departmentManagement'
      },
      {
        title: '人员档案',
        icon: 'iconfont-renyuandanganguanli',
        path: '/base/personnelFiles'
      },
      {
        title: '人员类别',
        icon: 'iconfont-qunti',
        path: '/base/personCategory'
      },
      // {
      //   title: '存货分类',
      //   icon: 'iconfont-navicon-chfl',
      //   path: '/base/inventoryCategory'
      // },
      {
        title: '商品信息',
        icon: 'iconfont-shangpinfenlei',
        path: '/base/merchandiseInformation'
      },
      {
        title: '仓库管理',
        icon: 'iconfont-cangkuguanli-',
        path: '/base/warehouseManagement'
      }
    ]
  },
  {
    title: '采购管理',
    icon: 'iconfont-caigou',
    children: [
      {
        title: '进货订单',
        icon: 'iconfont-jinhuodan',
        path: '/purchase/purchaseOrder'
      }]
  },
  {
    title: '销售管理',
    icon: 'iconfont-xiaoshoubaobiao',
    children: [
      {
        title: '销售单',
        icon: 'iconfont-xiaoshoudanju',
        path: '/sales/salesOrder'
      },
      {
        title: '销售开票',
        icon: 'iconfont-xiaoshoukaipiao-',
        path: '/sales/salesInvoicing'
      }]
  },
  {
    title: '零售管理',
    icon: 'iconfont-retail',
    children: [
      {
        title: '门店设置',
        icon: 'iconfont-mendian',
        path: '/retail/storeSettings'
      },
      {
        title: '收银员设置',
        icon: 'iconfont-shouyin',
        path: '/retail/cashierSettings'
      },
      {
        title: '门店存货表',
        icon: 'iconfont-cunhuo',
        path: '/retail/storeInventory'
      },
      {
        title: '零售单',
        icon: 'iconfont-Order',
        path: '/retail/retailOrders'
      }
    ]
  },
  {
    title: '库存管理',
    icon: 'iconfont-kucunguanli',
    children: [
      {
        title: '调拨单',
        icon: 'iconfont-tiaobodan',
        path: '/inventory/transferOrder'
      },
      {
        title: '盘点单',
        icon: 'iconfont-navicon-pdd',
        path: '/inventory/countingSheets'
      },
      {
        title: '库存量查询',
        icon: 'iconfont-kucunliang',
        path: '/inventory/inventoryQuery'
      }
    ]
  },
  {
    title: '会员管理',
    icon: 'iconfont-huiyuan-',
    children: [
      {
        title: '会员档案',
        icon: 'iconfont-huiyuandangan',
        path: '/member/memberFiles'
      },
      {
        title: '积分管理',
        icon: 'iconfont-jifen',
        path: '/member/pointsManagement'
      },
      {
        title: '会员充值',
        icon: 'iconfont-3',
        path: '/member/memberRecharge'
      }]
  },
  {
    title: '财务管理',
    icon: 'iconfont-caiwu',
    children: [
      {
        title: '收款单',
        icon: 'iconfont-shoukuan',
        path: '/financial/collectionSlips'
      },
      {
        title: '付款单',
        icon: 'iconfont-fukuan',
        path: '/financial/paymentSlip'
      }]
  },
  {
    title: '报表查询',
    icon: 'iconfont-baobiao',
    children: [
      {
        title: '采购报表',
        icon: 'iconfont-caigoudingdan-',
        path: '/report/purchaseReport'
      },
      {
        title: '销售报表',
        icon: 'iconfont-xiaoshoudanju',
        path: '/report/salesReport'
      },
      {
        title: '零售报表',
        icon: 'iconfont-Order',
        path: '/report/retailReports'
      },
      {
        title: '库存报表',
        icon: 'iconfont-kucunguanli',
        path: '/report/inventoryReport'
      },
      {
        title: '财务报表',
        icon: 'iconfont-financial_statements',
        path: '/report/financialStatements'
      }
    ]
  },
  {
    title: '系统管理',
    icon: 'gear',
    children: [
      {
        title: '个人信息',
        icon: 'address-card',
        path: '/system/personSetting'
      },
      {
        title: '系统配置',
        icon: 'iconfont-xitongguanli',
        path: '/system/systemConfiguration'
      },
      {
        title: '权限管理',
        icon: 'iconfont-fenghuangxiangmutubiao_quanxian',
        path: '/system/systemConfiguration'
      },
      {
        title: '操作日志',
        icon: 'iconfont-icon-test',
        path: '/log'
      }
    ]
  }
]
