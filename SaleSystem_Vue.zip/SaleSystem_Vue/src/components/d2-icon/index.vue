<template>
  <i  :class="name.indexOf('iconfont-')===-1?['fa',`fa-${name}`]:['iconfont',`${name}`]" aria-hidden="true"></i>
</template>

<script>
import './font-awesome-4.7.0/css/font-awesome.min.css'
import './iconfont/iconfont.css'
export default {
  name: 'd2-icon',
  props: {
    name: {
      type: String,
      required: false,
      default: 'font-awesome'
    }
  }
}
</script>
