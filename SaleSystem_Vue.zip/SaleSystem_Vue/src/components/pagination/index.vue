<!-- 通用分页组件 -->
<template>
    <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="pageIndex"
        :page-sizes="[5, 10, 15]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next"
        :total="pageTotal">
    </el-pagination>
</template>

<script>
export default {
  name: 'pagination', // 组件命名
  props: ['message'], // 接收父组件传输过来的数据
  data () {
    return {
      pageSize: this.message.size,
      pageIndex: this.message.curr,
      pageTotal: this.message.total
    }
  },
  methods: {
    // 每页显示多少条
    handleSizeChange (val) {
      this.pageSize = val
      this.pageIndex = 1
      this.handleCurrentChange()
    },

    // 页码的变化
    handleCurrentChange (val) {
      if (val) this.pageIndex = val
      this.$emit('paginationMessage', this.message)
    }

  }
}

</script>

<style>
   .el-pagination{
      margin-top: 12px;
      padding: 0;
   }
</style>
