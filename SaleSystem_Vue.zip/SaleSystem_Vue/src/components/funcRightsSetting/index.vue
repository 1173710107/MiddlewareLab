<template>
  <div class="funcSetting-container">
    <div class="current-chosen-user">
      <span>
        当前选中用户：<span>{{roleName}}</span>
      </span>
    </div>
    <el-row :gutter="48">
      <el-col :span="12">
        <div class="sub-title">
          <span>页面权限配置</span>
        </div>
        <el-tree
          :data="funcSettingData"
          show-checkbox
          :check-strictly = "false"
          :check-on-click-node = "false"
          node-key="functionId"
          ref="tree"
          expand-on-click-node
          highlight-current
          :default-expand-all = "true"
          :props="defaultProps"
          @node-click="nodeClick"
          @check-change="checkboxClick"
          >
        </el-tree>
      </el-col>
      <el-col :span="12">
        <div class="sub-title">
          <span>页面功能按钮权限配置</span>
        </div>
        <div v-if="currentButtons.length>0" >
         <el-checkbox
            v-model="item.state"
            @change="buttonsChange(item)"
            :label="item.buttonName"
            v-for="(item,index) in currentButtons"
            :key="index"
          ></el-checkbox>
        </div>
        <div class="no-btns" v-else>
          <p>该模块暂无功能按钮配置</p>
        </div>
      </el-col>
    </el-row>
    <el-row slot="footer"  class = "footer-btn">
      <el-button @click="submit">确 定</el-button>
      <el-button @click="cancel">取 消</el-button>
    </el-row>

  </div>
</template>
<script>
const roleManagementApi = require('../../api/roleManagement')
export default {
  name: 'role-function-setting', // 组件命名
  props: ['roleInfo'], // 接收父组件传输过来的数据
  data () {
    return {
      defaultProps: {
        children: 'childrenList',
        label: 'functionName'
      },
      funcSettingData: [],
      buttonsData: [],
      currentButtons: [],
      roleId: this.roleInfo.roleId,
      roleName: this.roleInfo.roleName
    }
  },
  watch: {
    roleInfo: {
      handler: function (val, oldval) {
        this.getfuncRightData()
      },
      deep: true// 对象内部的属性监听
    }
  },
  created () {
    this.getfuncRightData()
  },
  methods: {
    getfuncRightData () {
      roleManagementApi.getfuncRightUrl({ 'roleId': this.roleId }).then(res => {
        if (res.data.status === 200) {
          this.$refs.tree.setCheckedKeys(res.data.content.selectedIds)
          this.funcSettingData = res.data.content.treeList
          this.buttonsData = res.data.content.buttonList.map(item => {
            item.childrenList.forEach(btn => {
              btn.state = JSON.parse(btn.state)
            })
            return item
          })
        } else {
          this.$notify.error({ title: res.data.message })
        }
      }).catch(res => {
        this.$notify.error({ title: '请刷新重试' })
      })
    },

    // 点击节点时的回调
    nodeClick (node, state) {
      this.currentButtons = []
      this.buttonsData.forEach(item => {
        if (node.functionId === item.functionId) {
          this.currentButtons = item.childrenList
        }
      })
    },
    // 点击复选框回调
    checkboxClick (node, state) {
      this.currentButtons = []
      if (!node.childrenList) {
        for (let i = 0; i < this.buttonsData.length; i++) {
          if (node.functionId === this.buttonsData[i].functionId) {
            this.buttonsData[i].childrenList.forEach((val, index, arr) => {
              arr[index].state = state
            })
            this.currentButtons = this.buttonsData[i].childrenList
          }
        }
      }
    },
    // 按钮权限的分配
    buttonsChange (item) {
      for (let i = 0; i < this.buttonsData.length; i++) {
        this.buttonsData[i].childrenList.forEach((val, index, arr) => {
          if (val.buttonId === item.buttonId) {
            arr[index].state = item.state
          }
        })
      }
    },
    submit () {
      var keys = this.$refs.tree.getCheckedKeys()
      for (let i = 0; i < this.buttonsData.length; i++) {
        this.buttonsData[i].childrenList.forEach((val, index, arr) => {
          if (val.state) {
            keys.push(val.buttonId)
          }
        })
      }
      var query = {
        'roleId': this.roleId,
        'funtionIds': keys.join(';')
      }
      roleManagementApi.submitSysRoleFunction(query).then(res => {
        if (res.data.status === 200) {
          this.$emit('dialogVisibile', false)
        } else {
          this.$notify.error({ title: res.data.message })
        }
      }).catch(res => {
        this.$notify.error({ title: '请刷新重试' })
      })
    },
    // 取消
    cancel () {
      this.$emit('dialogVisibile', false)
    }
  }

}
</script>
<style lang="less">
  // @import "../less/layout.css";
    .roleHeader{
       background-color: #F3F3F3;
       height: 50px;
       line-height: 50px;
       padding-left: 10px;
    }
    .roleSetting{
       display: flex;
      /* justify-content:center;
       box-sizing: border-box;
       flex-wrap: wrap;
       align-content:center; */
       box-shadow:0 0 5px #b9b1b1;
    }
    .roleSetting-left{
      flex:1;

    }
    .roleSetting-right{
      flex:1;
    }
    .setting-title{
      padding:10px 5px;
    }
  .funcSetting-container{
    margin: 16px 16px 0 16px;
    max-height: 62vh;
    .current-chosen-user{
      margin-bottom: 8px;
      height: 44px;
      span{
        font-size: 22px;
      }
    }

    div.sub-title{
      margin-bottom: 12px;
      span{
        font-size: 18px;
      }
    }
    .el-row{
      padding: 0 8px;
      .el-col:first-child{
         max-height: 500px;
         overflow-y: scroll;
      }
    }
    .el-dialog__body{
      min-height: 640px;
    }
    .el-tree{
      border-right: 1px dashed #e0e0e0;
      padding-right: 48px;
    }
    .no-btns{
      position: relative;
      height: 440px;
      p{
        transform: translateY(-200%);
        text-align: center;
        position: absolute;
        font-size: 24px;
        color: #9d9d9d;
        width: 100%;
        top: 50%;
      }
    }

  }

  .footer-btn{
    position:absolute;
    right: 20px;
    height: 40px;
    line-height: 40px;
  }
</style>
