import request from '@/plugin/axios'

// 获取仓库列表
export const getDepartments = (data) => {
  if (!data) {
    data = { status: 2 }
  }
  return request.post('/warehouse/getList', data)
}

// 获取商店列表
export const getStores = (data) => {
  if (!data) {
    data = { status: 1 }
  }
  return request.post('/warehouse/getList', data)
}
