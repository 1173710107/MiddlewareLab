import request from '@/plugin/axios'

// 获取角色列表
export const getSysRoleList = (data) => {
  return request.post('/type/getList', data)
}
