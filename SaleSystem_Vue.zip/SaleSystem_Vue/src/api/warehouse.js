import request from '@/plugin/axios'

// 获取列表
export const getList = (data) => {
  return request.post('/warehouse/getList', data)
}

// 添加
export const add = (data) => {
  return request.post('/warehouse/add', data)
}

// 删除信息
export const del = (data) => {
  return request.post('/warehouse/delete', data)
}

// 根据id搜索
export const search = (data) => {
  return request.post('/warehouse/getById', data)
}

// 更新信息
export const update = (data) => {
  return request.post('/warehouse/update', data)
}
