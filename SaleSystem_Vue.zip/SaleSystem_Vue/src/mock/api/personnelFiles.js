const common = {
  status: 200,
  message: 'success'
}

export default [
  {
    path: '/api/SysEmpController/getSysEmpList',
    method: 'post',
    handle ({ body }) {
      return {
        'content': {
          'startIndex': 0,
          'currentPage': 1,
          'pageSize': 10,
          'pageTotal': 27,
          'recordTotal': 3,
          'list': [
            {
              'empId': 1,
              'empPhone': '',
              'empSex': '男',
              'empName': '管理员',
              'roleName': '系统管理员,财务处,运行处',
              'empNo': 'admin',
              'empState': 2,
              'departName': '44,工大二校区'
            },
            {
              'empId': 2,
              'empPhone': '',
              'empSex': '男',
              'empName': '总公司员工',
              'roleName': '44444,系统管理员,运行处',
              'empNo': '1',
              'empState': 1,
              'departName': '123,44'
            },
            {
              'empId': 3,
              'empPhone': '13244661234',
              'empSex': '男',
              'empName': '分公司员工',
              'roleName': '44444,夏利,系统管理员,运行处',
              'empNo': '2',
              'empState': 3,
              'departName': '44'
            },
            {
              'empId': 4,
              'empPhone': '',
              'empSex': '女',
              'empName': '班组员工',
              'roleName': '44444,系统管理员,运行处',
              'empNo': '3',
              'empState': 1,
              'departName': '123'
            },
            {
              'empId': 5,
              'empPhone': '',
              'empSex': '男',
              'empName': '没部门员工',
              'roleName': '44444,小妹,系统管理员',
              'empNo': '5',
              'empState': 1,
              'departName': '-'
            },
            {
              'empId': 6,
              'empPhone': '',
              'empSex': '男',
              'empName': '没有部门有角色员工',
              'roleName': '44444,系统管理员',
              'empNo': '6',
              'empState': 1,
              'departName': '-'
            },
            {
              'empId': 219,
              'empPhone': '',
              'empSex': '男',
              'empName': '测试',
              'roleName': '44444',
              'empNo': '51',
              'empState': 1,
              'departName': '44'
            },
            {
              'empId': 220,
              'empPhone': '',
              'empSex': '男',
              'empName': '测试',
              'roleName': '44444',
              'empNo': '52',
              'empState': 1,
              'departName': '123'
            },
            {
              'empId': 221,
              'empPhone': '',
              'empSex': '男',
              'empName': '测试',
              'roleName': '44444',
              'empNo': '53',
              'empState': 1,
              'departName': '44'
            },
            {
              'empId': 222,
              'empPhone': '',
              'empSex': '女',
              'empName': '测试',
              'roleName': '44444',
              'empNo': '54',
              'empState': 1,
              'departName': '123'
            }
          ]
        },
        ...common
      }
    }
  },
  {
    path: '/api/SysRoleController/getSysRoleSelect',
    method: 'post',
    handle ({ body }) {
      return {
        'content': [
          {
            'roleId': 1,
            'roleName': '系统管理员'
          },
          {
            'roleId': 2,
            'roleName': '运行处'
          },
          {
            'roleId': 3,
            'roleName': '财务处'
          },
          {
            'roleId': 16,
            'roleName': '夏利'
          },
          {
            'roleId': 17,
            'roleName': '小妹'
          },
          {
            'roleId': 18,
            'roleName': '44444'
          }
        ],
        ...common
      }
    }
  },
  {
    path: '/api/SysEmpController/getSysEmpById',
    method: 'post',
    handle ({ body }) {
      return {
        'content': {
          'sysEmpVo': {
            'empId': 1,
            'empNo': 'admin',
            'empName': '管理员',
            'empPassword': 'e10adc3949ba59abbe56e057f20f883e',
            'empSex': 'M',
            'empPhone': '',
            'empNote': '',
            'empState': 2,
            'isDelete': 1
          },
          'roleListChose': [
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'state': 'true'
            },
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'state': 'true'
            },
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'state': 'true'
            },
            {
              'roleId': 3,
              'roleName': '财务处',
              'state': 'true'
            },
            {
              'roleId': 2,
              'roleName': '运行处',
              'state': 'true'
            }
          ],
          'departListChose': [
            {
              'departId': '1'
            },
            {
              'departId': '3'
            }
          ],
          'roleList': [
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'state': 'true'
            },
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'state': 'true'
            },
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'state': 'true'
            },
            {
              'roleId': 3,
              'roleName': '财务处',
              'state': 'true'
            },
            {
              'roleId': 2,
              'roleName': '运行处',
              'state': 'true'
            },
            {
              'roleId': 16,
              'roleName': '夏利',
              'state': 'false'
            },
            {
              'roleId': 17,
              'roleName': '小妹',
              'state': 'false'
            },
            {
              'roleId': 18,
              'roleName': '44444',
              'state': 'false'
            }
          ],
          'departList': [
            {
              'departId': '1',
              'departName': '工大二校区',
              'parentDepartId': '0',
              'departState': 0,
              'departRelation': '1',
              'childList': [
                {
                  'departId': '2',
                  'departName': '123',
                  'parentDepartId': '1',
                  'departState': 1,
                  'departRelation': '1-2',
                  'childList': [
                    {
                      'departId': '3',
                      'departName': '44',
                      'parentDepartId': '2',
                      'departState': 1,
                      'departRelation': '1-2-3',
                      'state': 'true'
                    }
                  ],
                  'state': 'false'
                }
              ],
              'state': 'true'
            }
          ]
        },
        ...common
      }
    }
  }
]
