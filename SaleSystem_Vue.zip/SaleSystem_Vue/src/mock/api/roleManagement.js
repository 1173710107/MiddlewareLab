const common = {
  'status': 200,
  'message': 'success'
}
//
//
//
// /* ========================角色管理end=========================== */
//
// // 成功跳转
// router.use('/platformManagement/success', (req, res) => {
//   res.json(Mock.mock(common))
// })
//
// router.use('/middleware/setMWInspect', (req, res) => {
//   setTimeout(() => {
//     res.json(Mock.mock(common))
//   }, 1000 * 60 * 2)
// })

export default [
  {
    path: '/api/SysRoleController/getSysRoleList',
    method: 'post',
    handle ({ body }) { // sss
      return {
        'content': {
          'startIndex': 0,
          'currentPage': 1,
          'pageSize': 5,
          'pageTotal': 10,
          'recordTotal': 0,
          'list': [
            {
              'roleId': 1,
              'roleName': '系统管理员',
              'roleDate': 'Aug 8, 2019 10:25:53 AM',
              'roleNote': '系统管理员',
              'roleState': 2,
              'num': 1
            },
            {
              'roleId': 2,
              'roleName': '运行处',
              'roleDate': 'Aug 8, 2019 10:26:15 AM',
              'roleNote': '运行处',
              'roleState': 1,
              'num': 1
            },
            {
              'roleId': 3,
              'roleName': '财务处',
              'roleDate': 'Aug 8, 2019 10:26:40 AM',
              'roleNote': '财务管理',
              'roleState': 0,
              'num': 1
            }
          ]
        },
        ...common
      }
    }
  },
  {
    path: '/api/SysRoleController/getSysRoleFunctionList',
    method: 'post',
    handle ({ body }) { // sss
      return {
        'content': {
          'treeList': [{
            'functionId': 1,
            'functionName': '平台管理',
            'childrenList': [{
              'functionId': 12,
              'functionName': '部门管理',
              'state': 'true'
            }, {
              'functionId': 14,
              'functionName': '角色管理',
              'state': 'true'
            }, {
              'functionId': 15,
              'functionName': '角色分配',
              'state': 'true'
            }, {
              'functionId': 16,
              'functionName': '数据权限管理',
              'state': 'true'
            }, {
              'functionId': 17,
              'functionName': '设置记录',
              'state': 'true'
            }],
            'state': 'true'
          }, {
            'functionId': 2,
            'functionName': '热费管理',
            'childrenList': [{
              'functionId': 13,
              'functionName': '员工管理',
              'state': 'true'
            }],
            'state': 'true'
          }, {
            'functionId': 5,
            'functionName': '数据及诊断',
            'childrenList': [{
              'functionId': 24,
              'functionName': '运行监督',
              'state': 'false'
            }],
            'state': 'true'
          }, {
            'functionId': 18,
            'functionName': '首页',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 3,
            'functionName': '热网信息配置',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 4,
            'functionName': '数据接口',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 6,
            'functionName': '经济运行',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 7,
            'functionName': '系统分析',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 8,
            'functionName': '系统安全',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 9,
            'functionName': '热用户管理',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 10,
            'functionName': '客服管理',
            'childrenList': [],
            'state': 'false'
          }, {
            'functionId': 11,
            'functionName': '巡检与维修',
            'childrenList': [],
            'state': 'false'
          }],
          'selectedIds': [1, 12, 14, 15, 16, 17, 2, 13, 5],
          'buttonList': [{
            'functionId': 13,
            'functionName': '员工管理',
            'childrenList': [{
              'buttonName': '查询',
              'buttonId': 25,
              'state': 'true'
            }, {
              'buttonName': '添加',
              'buttonId': 26,
              'state': 'true'
            }, {
              'buttonName': '批量删除',
              'buttonId': 27,
              'state': 'false'
            }]
          },
          {
            'functionId': 15,
            'functionName': '员工管理',
            'childrenList': [{
              'buttonName': 'AAAA',
              'buttonId': 50,
              'state': 'true'
            }, {
              'buttonName': 'BBBB',
              'buttonId': 51,
              'state': 'true'
            }, {
              'buttonName': 'CCCC',
              'buttonId': 52,
              'state': 'false'
            }]
          }
          ]
        },
        ...common
      }
    }
  },
  {
    path: '/api/SysEmpController/getSysRoleListIsChoice',
    method: 'post',
    handle ({ body }) {
      return {
        'content': {
          'startIndex': 0,
          'currentPage': 1,
          'pageSize': 5,
          'pageTotal': 1,
          'recordTotal': 0,
          'list': [
            {
              'empId': 2,
              'empNo': '1',
              'empName': '总公司员工',
              'empSex': 'M',
              'empPhone': '',
              'empNote': '',
              'empState': 1
            },
            {
              'empId': 4,
              'empNo': '3',
              'empName': '班组员工',
              'empSex': 'W',
              'empPhone': '',
              'empNote': '',
              'empState': 1
            }
          ]
        },
        ...common
      }
    }
  }
]
