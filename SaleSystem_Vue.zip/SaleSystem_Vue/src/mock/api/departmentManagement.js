const common = {
  status: 200,
  message: 'success'
}

//= ============================部门管理页面start=============================

export default [
  {
    path: '/api/SysDepartController/getSysDepartAll',
    method: 'post',
    handle ({ body }) {
      var results = [
        {
          'departId': '1',
          'departName': '总部',
          'parentDepartId': '0',
          'departState': 0,
          'num': 2,
          'departRelation': '1',
          'childList': [
            {
              'departId': '2',
              'departName': '仓库',
              'parentDepartId': '1',
              'departState': 1,
              'num': 6,
              'departRelation': '1-2',
              'childList': [
                {
                  'departId': '3',
                  'departName': '仓库1',
                  'parentDepartId': '2',
                  'departState': 1,
                  'num': 11,
                  'departRelation': '1-2-3'
                },
                {
                  'departId': '4',
                  'departName': '仓库2',
                  'parentDepartId': '2',
                  'departState': 1,
                  'num': 11,
                  'departRelation': '1-2-3'
                }
              ]
            },
            {
              'departId': '5',
              'departName': '商店',
              'parentDepartId': '1',
              'departState': 1,
              'num': 6,
              'departRelation': '1-2',
              'childList': [
                {
                  'departId': '6',
                  'departName': '商店1',
                  'parentDepartId': '2',
                  'departState': 1,
                  'num': 11,
                  'departRelation': '1-2-3'
                },
                {
                  'departId': '7',
                  'departName': '商店2',
                  'parentDepartId': '2',
                  'departState': 1,
                  'num': 11,
                  'departRelation': '1-2-3'
                }
              ]
            }
          ]
        }
      ]
      return {
        'content': results,
        ...common
      }
    }
  },
  {
    path: '/api/SysEmpController/getSysEmpListDepChose',
    method: 'post',
    handle ({ body }) {
      var results = [
        {
          'allEmp': [
            {
              'empId': 1,
              'empName': '管理员',
              'state': 'true'
            },
            {
              'empId': 3,
              'empName': '分公司员工',
              'state': 'true'
            },
            {
              'empId': 2,
              'empName': '总公司员工',
              'state': 'false'
            },
            {
              'empId': 4,
              'empName': '班组员工',
              'state': 'false'
            },
            {
              'empId': 5,
              'empName': '没部门员工',
              'state': 'false'
            },
            {
              'empId': 6,
              'empName': '没有部门有角色员工',
              'state': 'false'
            }
          ],
          'empState': [
            {
              'empId': 1,
              'empName': '管理员',
              'state': 'true'
            },
            {
              'empId': 3,
              'empName': '分公司员工',
              'state': 'true'
            }
          ]
        }
      ]
      return {
        'content': results,
        ...common
      }
    }
  }, {
    path: '/api/SysEmpController/getSysEmpListIsChoice',
    method: 'post',
    handle ({ body }) {
      var result = {
        'content': {
          'startIndex': 0,
          'currentPage': 1,
          'pageSize': 10,
          'pageTotal': 2,
          'recordTotal': 1,
          'list': [
            {
              'empId': 1,
              'empNo': 'admin',
              'empName': '管理员',
              'empSex': 'M',
              'empPhone': '',
              'empNote': '',
              'empState': 2
            },
            {
              'empId': 238,
              'empNo': 'lyp123',
              'empName': '李奕鹏',
              'empSex': 'M',
              'empPhone': '',
              'empNote': '',
              'empState': 1
            }
          ]
        },
        ...common
      }
      return result
    }
  },
  {
    path: '/api/SysDepartController/isDeleteSysDepart',
    method: 'post',
    handle ({ body }) {
      var result = {
        'status': 500,
        'message': '此部门已存在下级部门，不可删除'
      }
      return result
    }
  },
  {
    path: '/api/SysDepartController/deleteSysDepart',
    method: 'post',
    handle ({ body }) {
      var result = {
        'status': 500,
        'message': 'success'
      }
      return result
    }
  }
]
