import layoutHeaderAside from '@/layout/header-aside'

// 由于懒加载页面太多的话会造成webpack热更新太慢，所以开发环境不使用懒加载，只有生产环境使用懒加载
const _import = require('@/libs/util.import.' + process.env.NODE_ENV)

/**
 * 在主框架内显示
 */
const frameIn = [
  {
    path: '/',
    redirect: { name: 'index' },
    component: layoutHeaderAside,
    children: [
      // 首页
      {
        path: 'index',
        name: 'index',
        meta: {
          auth: true
        },
        component: _import('system/index')
      },
      {
        path: 'base/departmentManagement',
        name: 'department',
        meta: {
          title: '部门设置',
          auth: true
        },
        component: _import('base/departmentManagement')
      },
      {
        path: 'base/personnelFiles',
        name: 'personnelFiles',
        meta: {
          title: '人员档案',
          auth: true
        },
        component: _import('base/personnelFiles')
      },
      {
        path: 'base/personCategory',
        name: 'personCategory',
        meta: {
          title: '人员类别',
          auth: true
        },
        component: _import('base/personCategory')
      },
      {
        path: 'base/inventoryCategory',
        name: 'inventoryCategory',
        meta: {
          title: '人员类别',
          auth: true
        },
        component: _import('base/inventoryCategory')
      },
      // {
      //   path: 'base/inventoryCategory',
      //   name: 'inventoryCategory',
      //   meta: {
      //     title: '存货分类',
      //     auth: true
      //   },
      //   component: _import('base/inventoryCategory')
      // },
      {
        path: 'base/merchandiseInformation',
        name: 'merchandiseInformation',
        meta: {
          title: '商品信息',
          auth: true
        },
        component: _import('base/merchandiseInformation')
      },
      {
        path: 'base/warehouseManagement',
        name: 'warehouseManagement',
        meta: {
          title: '仓库管理',
          auth: true
        },
        component: _import('base/warehouseManagement')
      },
      {
        path: 'purchase/purchaseOrder',
        name: 'purchaseOrder',
        meta: {
          title: '进货订单',
          auth: true
        },
        component: _import('purchase/purchaseOrder')
      },
      {
        path: 'sales/salesOrder',
        name: 'salesOrder',
        meta: {
          title: '销售单',
          auth: true
        },
        component: _import('sales/salesOrder')
      },
      {
        path: 'sales/salesInvoicing',
        name: 'salesInvoicing',
        meta: {
          title: '销售开票',
          auth: true
        },
        component: _import('sales/salesInvoicing')
      },
      {
        path: 'retail/storeSettings',
        name: 'storeSettings',
        meta: {
          title: '门店设置',
          auth: true
        },
        component: _import('retail/storeSettings')
      }, {
        path: 'retail/cashierSettings',
        name: 'cashierSettings',
        meta: {
          title: '收银员设置',
          auth: true
        },
        component: _import('retail/cashierSettings')
      }, {
        path: 'retail/storeInventory',
        name: 'storeInventory',
        meta: {
          title: '门店存货表',
          auth: true
        },
        component: _import('retail/storeInventory')
      }, {
        path: 'retail/retailOrders',
        name: 'retailOrders',
        meta: {
          title: '零售单',
          auth: true
        },
        component: _import('retail/retailOrders')
      }, {
        path: 'inventory/transferOrder',
        name: 'transferOrder',
        meta: {
          title: '调拨单',
          auth: true
        },
        component: _import('inventory/transferOrder')
      }, {
        path: 'inventory/countingSheets',
        name: 'countingSheets',
        meta: {
          title: '盘点单',
          auth: true
        },
        component: _import('inventory/countingSheets')
      }, {
        path: 'inventory/inventoryQuery',
        name: 'inventoryQuery',
        meta: {
          title: '库存量查询',
          auth: true
        },
        component: _import('inventory/inventoryQuery')
      },
      {
        path: 'member/memberFiles',
        name: 'memberFiles',
        meta: {
          title: '会员档案',
          auth: true
        },
        component: _import('member/memberFiles')
      },
      {
        path: 'member/pointsManagement',
        name: 'pointsManagement',
        meta: {
          title: '积分管理',
          auth: true
        },
        component: _import('member/pointsManagement')
      },
      {
        path: 'member/memberRecharge',
        name: 'memberRecharge',
        meta: {
          title: '会员充值',
          auth: true
        },
        component: _import('member/memberRecharge')
      },
      {
        path: 'financial/collectionSlips',
        name: 'collectionSlips',
        meta: {
          title: '收款单',
          auth: true
        },
        component: _import('financial/collectionSlips')
      },
      {
        path: 'financial/paymentSlip',
        name: 'paymentSlip',
        meta: {
          title: '付款单',
          auth: true
        },
        component: _import('financial/paymentSlip')
      },
      {
        path: 'report/purchaseReport',
        name: 'purchaseReport',
        meta: {
          title: '采购报表',
          auth: true
        },
        component: _import('report/purchaseReport')
      },
      {
        path: 'report/salesReport',
        name: 'salesReport',
        meta: {
          title: '销售报表',
          auth: true
        },
        component: _import('report/salesReport')
      },
      {
        path: 'report/retailReports',
        name: 'retailReports',
        meta: {
          title: '零售报表',
          auth: true
        },
        component: _import('report/retailReports')
      },
      {
        path: 'report/inventoryReport',
        name: 'inventoryReport',
        meta: {
          title: '库存报表',
          auth: true
        },
        component: _import('report/inventoryReport')
      },
      {
        path: 'report/financialStatements',
        name: 'financialStatements',
        meta: {
          title: '财务报表',
          auth: true
        },
        component: _import('report/financialStatements')
      },
      {
        path: 'system/personSetting',
        name: 'personSetting',
        meta: {
          title: '个人信息',
          auth: true
        },
        component: _import('system/personSetting')
      },
      {
        path: 'system/systemConfiguration',
        name: 'systemConfiguration',
        meta: {
          title: '系统配置',
          auth: true
        },
        component: _import('system/systemConfiguration')
      },
      // 系统 前端日志
      {
        path: 'log',
        name: 'log',
        meta: {
          title: '操作日志',
          auth: true
        },
        component: _import('system/log')
      },
      // 刷新页面 必须保留
      {
        path: 'refresh',
        name: 'refresh',
        hidden: true,
        component: _import('system/function/refresh')
      },
      // 页面重定向 必须保留
      {
        path: 'redirect/:route*',
        name: 'redirect',
        hidden: true,
        component: _import('system/function/redirect')
      }
    ]
  }
]

/**
 * 在主框架之外显示
 */
const frameOut = [
  // 登录
  {
    path: '/login',
    name: 'login',
    component: _import('system/login')
  }
]

/**
 * 错误页面
 */
const errorPage = [
  {
    path: '*',
    name: '404',
    component: _import('system/error/404')
  }
]

// 导出需要显示菜单的
export const frameInRoutes = frameIn

// 重新组织后导出
export default [
  ...frameIn,
  ...frameOut,
  ...errorPage
]
