package Observer;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

public class Observer implements Runnable {

	private String name;
	private Socket socket;
	private boolean flag = false;
	private String msg = "";

	public Observer(String name) throws IOException {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void subscribe(String obseString, Socket skt) throws IOException {
		PrintWriter out = new PrintWriter(skt.getOutputStream());
		out.println("SUBSCRIBE@" + obseString + "@" + this.name);
		out.flush();
	}

	public void update(String str) throws IOException {
		this.flag = true;
		this.msg = str;
	}

	@Override
	public void run() {
		if (flag) {
			flag = false;
			String [] liStrings = msg.split("@");
			if(liStrings.length==3)
			{
				System.out.println(name+"观察者接收信息:被观察者"+liStrings[1]+"发送第"+liStrings[2]+"条消息---"+liStrings[0]);
			}
			try {
				if(liStrings[2].equals("22"))
				{
					Socket socket = new Socket(InetAddress.getLocalHost(),BrokerServer.SERVER_PORT);
					PrintWriter out=new PrintWriter(socket.getOutputStream());
					out.println("end@");
					out.flush();
				}
					
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public String toString() {
		return "Fans [name=" + name + ", socket=" + socket + ", flag=" + flag + ", msg=" + msg + "]";
	}

}
