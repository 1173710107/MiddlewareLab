package Observer;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;


public class Client {

    public static void main(String[] args) throws IOException, InterruptedException {
    	Socket socket = new Socket(InetAddress.getLocalHost(),BrokerServer.SERVER_PORT);
    	
    	 final long startTime = System.currentTimeMillis();    //获取开始时间
        Observer observer1 = new Observer("observer1");
        Observer observer2 = new Observer("observer2");
        Observer observer3 = new Observer("observer3");
        Observer observer4 = new Observer("observer4");
        Observerable observerable1 = new Observerable("observerable1",socket);
        Observerable observerable2 = new Observerable("observerable2",socket);
        
        new Thread(observer1).start();
        new Thread(observer2).start();
        new Thread(observer3).start();
        new Thread(observer4).start();
        observer1.subscribe("observerable1",socket);
        observer3.subscribe("observerable2",socket);
        observer4.subscribe("observerable2",socket);
        observer2.subscribe("observerable1",socket);
        for(int i=0;i<=10;i++)
        {
        	observerable1.movelUp("message"+(4*i+1));
            observerable2.movelUp("message"+(4*i+2));
            observerable1.movelUp("message"+(4*i+3));
            observerable2.movelUp("message"+(4*i+4));
        }
        
        System.out.println("----------------------------");

        observerable1.movelUp(startTime+"@");
    }
}
