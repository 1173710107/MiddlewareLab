package Observer;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Observerable {
    // 标识被观察者是否变化
    private boolean changed = false;
    private  Integer count = 0;
    private final Socket socket;
    private List<Observer> list = new ArrayList<>();
    
    public void addMovelListener(Observer o) {
        list.add(o);
    }

    public List<Observer> getList() {
        return list;
    }

    public void setList(List<Observer> list) {
        this.list = list;
    }

    public boolean isChanged() {
        return changed;
    }

    public void setChanged(boolean changed) {
        this.changed = changed;
    }

    public Observerable(String name, Socket socket) {
        super();
        this.name = name;
        this.socket = socket;
    }

    private String name;

    private String lastMovel;

    public void movelUp(String movel) throws IOException {
    	if(movel.contains("@"))
    	{
    		String list[] = movel.split("@");
    		PrintWriter out=new PrintWriter(socket.getOutputStream());
	        out.println("starttime@"+list[0]);
	        out.flush();
    	}
    	else {
    		 count++;
    	        System.out.println("被观察者"+name+"发布消息："+movel);
    	        PrintWriter out=new PrintWriter(socket.getOutputStream());
    	        out.println(movel+"@"+this.name+"@"+count.toString());
    	        out.flush();
		}
       
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastMovel() {
        return lastMovel;
    }

    public void setLastMovel(String lastMovel) {
        this.lastMovel = lastMovel;
    }

}