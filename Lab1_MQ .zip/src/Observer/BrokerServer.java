package Observer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BrokerServer implements Runnable {
    public static int SERVER_PORT=9998;
    public static int count=0;
    public static int countend=0;
    private static List<Observer> fans = new ArrayList();
    private static Map<String, List<Observer>> sub = new HashMap<>();
    private final Socket socket;
    public static long startTime;

    public BrokerServer(Socket socket){
        this.socket=socket;
    }
    public boolean   checkfan(String name) {
    	boolean flag = false;
    	for(Observer fan:fans)
    	{
    		if(fan.getName().equals(name))
    		{
    			flag = true;
    		}
    	}
    	return flag;
	}
    public boolean checkstar(String name)
    {
    	return sub.containsKey(name);
    }
    public boolean checkrelation(String starname,String fanname)
    {
    	boolean flag = false;
    	if(checkstar(starname)&&checkfan(fanname))
    	{
    		
    		List<Observer> observer1 = sub.get(starname);
    		for(Observer observer2 : observer1)
    		{
    			if(observer2.getName().equals(fanname))
    			{
    				flag = true;
    			}
    		}
    	}
    	return flag;
    }
    @Override
    public void run(){
        try {
            BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));//接收
            PrintWriter out=new PrintWriter(socket.getOutputStream());//发
            while(true){
                String str=in.readLine();
                if (str==null) {
                    continue;
                }
                count++;
                System.out.println("服务器端接收数据："+str);
                if (str.startsWith("SUBSCRIBE@")) {//观察者订阅
                    String[] spl = str.split("@");
                    boolean flag = false;
                    if(!checkfan(spl[2]))//检查观察者是否存在
                    {
                    	Observer observer1 = new Observer(spl[2]);
                    	observer1.setSocket(socket);
                    	fans.add(observer1);
                    }
                    if(!checkstar(spl[1]))//检查被观察者是否存在
                    {
                    	sub.put(spl[1], new ArrayList<Observer>());
                    }
                    if(!checkrelation(spl[1], spl[2]))//没有该观察者
                    {
                    	List<Observer> list = sub.get(spl[1]);
                    	Observer observer1 = new Observer(spl[2]);
                    	observer1.setSocket(socket);
                    	list.add(observer1);
                    }
                    System.out.println("观察者"+spl[2]+"订阅被观察者"+spl[1]+"成功");
                 
                }
                else if(str.startsWith("starttime@")) {
                	String list [] = str.split("@");
                	 startTime = Long.valueOf(list[1]);
                }
                else if(str.startsWith("end"))
                {
                	countend++;
                	if(countend==4)
                	{
                		long endTime = System.currentTimeMillis();    //获取结束时间
                    	System.out.println("程序运行时间：" + (endTime - startTime) + "ms");
                        System.out.println("中间件共发送消息：" + count + "条");
                        System.out.println("吞吐率为：" + 1000*count/(endTime - startTime) );
                	}
                }
                else{//给观察者发送消息
                	count++;
                	 String[] spl = str.split("@");
                     if(spl.length==3)
                     {
                     	 String star = spl[1];
                          List<Observer> fan = sub.get(star);
                          for(int i = 0; i < fan.size(); i++){
                              out.println(str);
                              out.flush();
                              new Thread(fan.get(i)).start();
                              fan.get(i).update(str);
                          }
                     }
                     else {
             			System.out.println("被观察者发送消息格式错误！");
             		}
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(SERVER_PORT);
        while (true) {
            BrokerServer borkerServer=new BrokerServer(server.accept());
            new Thread(borkerServer).start();
        }
    }
}
